<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo de Personagens - Hollow Knight</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-image: url(./assets/background.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center center;
            background-attachment: fixed;
            color: #f4f4f4;
            min-height: 90vh;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: center;
            padding-bottom: 2rem;
        }

        .header img {
            height: 100px;
        }

        .container-catalogo {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            justify-content: center;
            padding-bottom: 30px;
        }

        .card {
            background-color: #000;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.7);
            display: flex;
            width: 450px;
            overflow: hidden;
            border: 1px solid #222;
            position: relative;
        }

        .card-foto {
            width: 180px;
            flex-shrink: 0;
            padding: 12px;
            box-sizing: border-box;
        }

        .card-foto img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            border-radius: 6px;
        }

        .card-info {
            padding: 15px 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .card-info h3 {
            margin-top: 0;
            margin-bottom: 15px;
            color: #f4f4f4;
            font-size: 1.3rem;
        }

        .card-info h4 {
            margin-top: 0;
            margin-bottom: 10px;
            color: #ddd;
            border-bottom: 1px solid #333;
            padding-bottom: 5px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .card-info .habilidades {
            font-size: 0.9em;
            color: #C5C5C5FF;
            line-height: 1.6;
            flex-grow: 1;
            margin-bottom: 15px;
        }

        .card-acoes {
            margin-top: auto;
        }

        .btn-editar {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #f4f4f4;
            text-align: center;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            box-sizing: border-box;
            transition: background-color 0.2s;
        }

        .btn-editar:hover {
            background-color: #444;
        }

        .link-excluir {
            position: absolute;
            top: 10px;
            right: 12px;
            text-decoration: none;
            color: #ff3333;
            font-size: 1.3rem;
            transition: color 0.2s, transform 0.2s;
        }

        .link-excluir:hover {
            color: #ff6666;
            transform: scale(1.1);
        }

        .link-adicionar {
            display: block;
            text-align: center;
            margin: 20px auto;
            padding: 12px 20px;
            font-size: 1.1em;
            text-decoration: none;
            color: #fff;
            background-color: rgba(0, 123, 255, 0.8);
            border: 1px solid rgba(0, 123, 255, 1);
            border-radius: 6px;
            font-weight: bold;
            width: 250px;
            box-sizing: border-box;
            transition: background-color 0.2s;
        }

        .link-adicionar:hover {
            background-color: rgba(0, 123, 255, 1);
        }
    </style>
</head>

<body>

    <div class="header">
        <img src="./assets/logo.png" alt="Logo Hollow Knight">
    </div>

    <a href="index.php?acao=form" class="link-adicionar">+ Adicionar Personagem</a>
    <br>

    <div class="container-catalogo">
        <?php foreach ($personagens as $personagem): ?>
            <div class="card">

                <a href="index.php?acao=deletar&id=<?= $personagem['id'] ?>" class="link-excluir"
                    onclick="return confirm('Deseja excluir <?= htmlspecialchars($personagem['nome']) ?>?');">
                    🗑️
                </a>

                <div class="card-foto">
                    <img src="assets/<?= htmlspecialchars($personagem['arquivo_foto']) ?>"
                        alt="<?= htmlspecialchars($personagem['nome']) ?>">
                </div>

                <div class="card-info">
                    <h3><?= htmlspecialchars($personagem['nome']) ?></h3>

                    <h4>Habilidades</h4>
                    <div class="habilidades">
                        <?php
                        echo nl2br(htmlspecialchars($personagem['habilidades']));
                        ?>
                    </div>

                    <div class="card-acoes">
                        <a href="index.php?acao=editar&id=<?= $personagem['id'] ?>" class="btn-editar">Editar</a>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>


</body>

</html>