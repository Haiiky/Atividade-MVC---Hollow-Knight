<?php

require_once __DIR__ . "/../config/database.php";


function listarPersonagens() {
    $pdo = getConnection();
    $sql = "SELECT * FROM personagens ORDER BY nome";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function adicionarPersonagem($nome, $arquivo_foto, $habilidades) {
    $pdo = getConnection();
    $sql = "INSERT INTO personagens (nome, arquivo_foto, habilidades) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([$nome, $arquivo_foto, $habilidades]);
}

function buscarPersonagemPorId($id){
    $pdo = getConnection();
    $sql = "SELECT * FROM personagens WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function atualizarPersonagem($id, $nome, $arquivo_foto, $habilidades) {
    $pdo = getConnection();
    $sql = "UPDATE personagens SET nome = ?, arquivo_foto = ?, habilidades = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([$nome, $arquivo_foto, $habilidades, $id]);
}

function excluirPersonagem($id) {
    $pdo = getConnection();
    $sql = "DELETE FROM personagens WHERE id = ?";
    $stmt = $pdo->prepare($sql);   
    return $stmt->execute([$id]);
}