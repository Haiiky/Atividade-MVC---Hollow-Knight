<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Personagem</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-image: url(./assets/background.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center center;
            background-attachment: fixed;
            color: #f4f4f4;
            min-height: 90vh;
        }

        .header {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding-bottom: 1rem;
        }

        .header img {
            height: 100px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #000;
        }

        div {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 95%;
            padding: 8px;
            border:none;
            color: #ffffff;
            border-radius: 4px;
            background-color: #444444FF;
        }

        textarea {
            height: 100px;
        }

        button {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        small {
            color: #777;
        }
    </style>
</head>

<body>
    <div class="header">
        <img src="./assets/logo.png" alt="Logo Hollow Knight">
        <h1>Novo Personagem</h1>

    </div>
    <form action="index.php?acao=salvar" method="POST">
        <div>
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>
        </div>
        <div>
            <label for="arquivo_foto">Nome do Arquivo da Foto:</label>
            <input type="text" id="arquivo_foto" name="arquivo_foto" required>
            <small>Ex: knight.png (deve estar na pasta /assets/)</small>
        </div>
        <div>
            <label for="habilidades">Habilidades:</label>
            <textarea id="habilidades" name="habilidades"></textarea>
            <small>Coloque uma habilidade por linha.</small>
        </div>
        <button type="submit">Salvar</button>
    </form>
</body>

</html>