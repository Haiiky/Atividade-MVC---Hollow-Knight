<?php

require_once __DIR__ . "/controllers/personagemController.php";

$acao = $_GET['acao'] ?? 'index';

switch ($acao) {
    case 'index':
        index();
        break;
    case 'deletar':
        deletar();
        break;
    case 'form':
        require __DIR__ . "/views/personagens_form.php";
        break;
    case 'salvar': 
        salvar();
        break;
    case 'atualizar':
        atualizar();
        break;
    case 'editar':
        editar();
        break;
    default:
        echo "Ação não encontrada";
}