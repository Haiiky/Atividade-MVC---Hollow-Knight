<?php

require_once __DIR__ . "/../models/personagem.php";

function index() {
    $personagens = listarPersonagens();
    require __DIR__ . "/../views/personagens_listar.php";
}

function deletar() {
    if(!empty($_GET['id'])) {
        excluirPersonagem($_GET['id']);
    }
    header('Location: index.php');
    exit;
}

function salvar() {
    if(!empty($_POST['nome']) && !empty($_POST['arquivo_foto'])) {
        adicionarPersonagem($_POST['nome'], $_POST['arquivo_foto'], $_POST['habilidades']);
    }
    header("Location: index.php");
    exit;
}

function editar() {
    if(!empty($_GET['id'])) {
        $personagem = buscarPersonagemPorId($_GET['id']);
        
        if ($personagem) { 
            require __DIR__ . '/../views/personagens_editar.php';
            return; 
        }
    }
    header('Location: index.php');
    exit;
}

function atualizar() {
    if(!empty($_POST['id']) && !empty($_POST['nome']) && !empty($_POST['arquivo_foto'])) {
        atualizarPersonagem($_POST['id'], $_POST['nome'], $_POST['arquivo_foto'], $_POST['habilidades']);
    }
    header("Location: index.php");
    exit;
}